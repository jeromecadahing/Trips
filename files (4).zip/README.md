# Trip Ledger

A personal trip planner that runs entirely in the browser. Track future trips, their costs and budgets, how long it will take to save for (or pay off) each one, day-by-day itineraries, flight and transport details, what-if simulations, and quick flight searches.

No server, no build step, no account. It's one `trips.html` file, so it hosts for free on GitHub Pages, including alongside another site in the same repository.

## Features

- **Trips list** with countdown, savings progress and an on-track / behind status for each trip
- **Budget and payoff**: projected cost vs. budget, months until fully saved, the monthly amount needed to be ready by departure, and the interest cost if you put a shortfall on a card
- **Costs** by category, with estimates and actuals (actuals replace estimates once entered)
- **Flights and transport**: flights, trains, buses, car rentals, ferries, with times, booking refs and costs that roll into the trip total
- **Itinerary**: activities grouped by trip day, with a one-click "row for each day"
- **Simulate**: sliders for savings, monthly amount, price changes and APR, a balance-over-time chart, and a 3,000-run Monte Carlo estimate of the chance you're fully saved by departure
- **Savings plan**: one shared monthly amount split across all upcoming trips in departure order, shown as a timeline
- **Search flights**: opens the same search on Google Flights, Skyscanner, Kayak and Rome2Rio, and logs the fare you pick into a trip
- **Backup**: export and import your data as JSON

## Put it on GitHub Pages

1. Open the repository (for example your budget tracker).
2. Upload `trips.html` next to your existing files (Add file → Upload files → Commit). Don't rename it to `index.html`, or it will replace the site that's already there.
3. If the repository isn't on GitHub Pages yet, go to **Settings → Pages**, set Source to **Deploy from a branch**, branch **main**, folder **/ (root)**, then Save.
4. After a minute the app is live at `https://<your-username>.github.io/<repo-name>/trips.html`.

To update it later, upload the new `trips.html` over the old one and commit.

Or from the command line:

```bash
cd path/to/your-repo
cp ~/Downloads/trips.html .
git add trips.html
git commit -m "Update trip planner"
git push
```

## Where your data lives

Trips are stored in your browser's `localStorage` for that site. They don't sync between devices or browsers, and clearing site data erases them, so use **Settings → Export backup** regularly. Nothing is sent to any server. The repository itself only holds the app, not your trips, so it's safe to keep it public.

## About flight search

The search page builds links that open live searches on the booking sites; prices come from those sites, not from this app. Showing live fares inside the app would require a flight-data API and an API key, which can't be kept secret in a public static site. If you want that later, the usual approach is a small serverless function (Cloudflare Workers, Netlify or Vercel functions) that holds the key and that `trips.html` calls.

## Customising

Everything is in `trips.html`: colours are CSS variables at the top of the `<style>` block, cost categories and transport types are the `CATS` and `MODES` arrays at the top of the script, and the example trips are in `sample()`.
